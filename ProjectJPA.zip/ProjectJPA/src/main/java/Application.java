import entities.Author;
import entities.Book;

import org.hibernate.Session;
import util.HibernateUtil;

import java.util.List;
import java.util.List.*;

public class Application {
    public static void main(String[] args) {
        Book book= new Book();
        System.out.println(getBooks());
    }
    public  static List<Book> getBooks (){
        Session session=HibernateUtil.getSessionFactory().openSession();
        List<Book> books= session.createQuery("select  b from Book b inner join b.author ").list();
        session.close();
        return books;
    }
    //public  static  List<Book> get

}
// public  static   List<Employee> getEmployee (String firstLetter, int age){
////        Session session=HibernateUtil.getSessionFactory().openSession();
////        List<Employee> employees= session.createQuery("FROM  Employee where name like :pname  and age >:p_age")
////                .setParameter("pname", firstLetter).setParameter("p_age", age).list();
////        session.close();
////        return  employees;
////    }